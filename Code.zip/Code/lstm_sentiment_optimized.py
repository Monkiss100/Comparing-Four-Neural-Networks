import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, LSTM, GlobalMaxPooling1D, Dense, Dropout, Bidirectional
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder , OneHotEncoder
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.utils import to_categorical
import matplotlib.pyplot as plt
from sklearn.metrics import precision_score, recall_score, f1_score, confusion_matrix, classification_report
import seaborn as sns
import time
import torch

print(torch.cuda.is_available()) #Make use GPU

start_time = time.time()

data = pd.read_csv('dataCleaned_with_sentiment_full_final.csv')

def preprocess_data(data):
    data['self_text'] = data['self_text'].fillna('').astype(str) #Make sure all are strings

    texts = data['self_text'].values
    labels = data['sentiment_score'].values  # allows neg neut and posi

    # Tokenize and pad sequences
    tokenizer = Tokenizer(num_words=10000)
    tokenizer.fit_on_texts(texts)
    sequences = tokenizer.texts_to_sequences(texts)
    word_index = tokenizer.word_index

    padded_sequences = pad_sequences(sequences, maxlen=100)

    # Encode labels


    # removed label encoder        ADD BACK IN!!!!!!
    one_hot_encoder = OneHotEncoder(sparse_output=False)  # fix
    one_hot_labels = one_hot_encoder.fit_transform(labels.reshape(-1, 1))

    return padded_sequences, one_hot_labels, tokenizer                                      #LABEL ENCODER BACK IN!!!!!!!!

padded_sequences, one_hot_labels, tokenizer = preprocess_data(data)

unique, counts = np.unique(data['sentiment_score'], return_counts=True)
print(dict(zip(unique, counts)))

# Split data
X_train, X_test, y_train, y_test = train_test_split(
    padded_sequences, one_hot_labels, test_size=0.2, random_state=10)

# Build CNN model
model = Sequential([
    Embedding(input_dim=10000, output_dim=200, input_length=100),
    Bidirectional(LSTM(128, return_sequences=True, recurrent_dropout=0.2)),  # Bidirectional layer
    LSTM(64, return_sequences=False, recurrent_dropout=0.2),
    Dense(64, activation='relu'),
    Dropout(0.4),
    Dense(one_hot_labels.shape[1], activation='softmax')
])

model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
model.summary()

# Train the model
epochs = 4
batch_size = 128
history = model.fit(X_train, y_train, epochs=epochs, batch_size=batch_size, validation_split=0.2)

# Evaluate the model
eval_results = model.evaluate(X_test, y_test, verbose=0)
print(f"Test Loss: {eval_results[0]:.4f}, Test Accuracy: {eval_results[1]:.4f}")         #Test Loss: 0.5381, Test Accuracy: 0.8541

#Runtime
end_time = time.time()
runtime = end_time - start_time
print(f"Runtime: {runtime:.3f} seconds")

# Predict on test data
y_pred_probs = model.predict(X_test)
y_pred_classes = np.argmax(y_pred_probs, axis=1)
y_true_classes = np.argmax(y_test, axis=1)

#precision = precision_score(y_true_classes, y_pred_classes, average="weighted")                                                # Precision: 0.8376, Recall: 0.8389, F1-score: 0.8382
#recall = recall_score(y_true_classes, y_pred_classes, average="weighted")
#f1 = f1_score(y_true_classes, y_pred_classes, average="weighted")
#print(f"Precision: {precision:.4f}, Recall: {recall:.4f}, F1-score: {f1:.4f}")

# classification report
print(classification_report(y_true_classes, y_pred_classes, digits=4))


# Confusion matrix
conf_matrix = confusion_matrix(y_true_classes, y_pred_classes, labels=[0, 1, 2])                                              #Top left true negative, Top right false positive, Bottom left false negative, Bottom right true positive

# Visualize Confusion Matrix
plt.figure(figsize=(8, 6))
sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='Blues', xticklabels= ['Negative (-1)', 'Neutral (0)', 'Positive (1)'],
            yticklabels= ['Negative (-1)', 'Neutral (0)', 'Positive (1)'])
plt.xlabel('Predicted Labels')
plt.ylabel('True Labels')
plt.title('LSTM with Optimization and Full Dataset Confusion Matrix')
plt.show()

model.save("lstm_opti4.keras")
import pandas as pd
import torch
import random
from transformers import AutoTokenizer, AutoModelForSequenceClassification
from transformers import pipeline
import re

print(torch.cuda.is_available()) #Make use GPU

data = pd.read_csv('reddit_opinion_PSE_ISR.csv')


if 'self_text' not in data.columns:
    raise ValueError("self_text missing")


def clean_text(text):
    if not isinstance(text, str):
        return ""
    text = text.lower()
    text = re.sub(r'http\S+', '', text)
    text = re.sub(r'[^a-zA-Z0-9\s]', '', text)  #Remove urls, specials characters ans spaces
    text = re.sub(r'\s+', ' ', text).strip()
    return text

#Cleaning
data['self_text'] = data['self_text'].apply(clean_text)
data['created_time'] = data['created_time'].apply(clean_text)


sentiment_pipeline = pipeline("sentiment-analysis", model="cardiffnlp/twitter-roberta-base-sentiment")  #changed to cardiff for neutral classification
tokenizer = AutoTokenizer.from_pretrained("cardiffnlp/twitter-roberta-base-sentiment")

# Shorten text
def preprocess_text(text, max_length=512):
    tokens = tokenizer(text, truncation=True, max_length=max_length, return_tensors="pt")
    return tokenizer.decode(tokens["input_ids"][0], skip_special_tokens=True)

data['self_text'] = data['self_text'].apply(lambda x: preprocess_text(x))

# Adds sentiment scores for text
sentiment_scores = []
for text in data['self_text']:
    result = sentiment_pipeline(text)[0]
    # sentiment labels are 0 = negative, 1 = neutral, 2 = positive
    label_map = {"LABEL_0": -1, "LABEL_1": 0, "LABEL_2": 1}
    sentiment_scores.append(label_map[result['label']])

# Create a new column
data['sentiment_score'] = sentiment_scores

data.to_csv("dataCleaned_with_sentiment_full_final.csv", index=False)

print("Saved as dataCleaned_with_sentiment.csv")
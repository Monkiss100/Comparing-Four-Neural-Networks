import pandas as pd
import torch
import random
from transformers import AutoTokenizer, AutoModelForSequenceClassification
from transformers import pipeline
import re

print(torch.cuda.is_available()) #Make use GPU

data = pd.read_csv('reddit_opinion_PSE_ISR.csv')


if 'self_text' not in data.columns:
    raise ValueError("self_text missing")


def clean_text(text):
    if not isinstance(text, str):
        return ""
    text = text.lower()
    text = re.sub(r'http\S+', '', text)
    text = re.sub(r'[^a-zA-Z0-9\s]', '', text)  #Remove urls, specials characters ans spaces
    text = re.sub(r'\s+', ' ', text).strip()
    return text

#Cleaning
data['self_text'] = data['self_text'].apply(clean_text)

# Select 10% of dataset
select_ten = int(len(data) * 0.1)
data_ten = data.sample(select_ten, random_state=10).reset_index(drop=True)             # random state stays the sames

sentiment_pipeline = pipeline("sentiment-analysis")
tokenizer = AutoTokenizer.from_pretrained("distilbert-base-uncased")    #BERT

# Shorten text
def preprocess_text(text, max_length=512):
    tokens = tokenizer(text, truncation=True, max_length=max_length, return_tensors="pt")
    return tokenizer.decode(tokens["input_ids"][0], skip_special_tokens=True)

data_ten['self_text'] = data_ten['self_text'].apply(lambda x: preprocess_text(x))

# Adds sentiment scores for text
sentiment_scores = []
for text in data_ten['self_text']:
    result = sentiment_pipeline(text)[0]
    # sentiment labels are -1 = negative, 0 = neutral, 1 = positive
    sentiment_score = 1 if result['label'] == 'POSITIVE' else -1 if result['label'] == 'NEGATIVE' else 0       # DOESNT WORK CANT DO 0
    sentiment_scores.append(sentiment_score)

# Create a new column
data_ten['sentiment_score'] = sentiment_scores

data_ten.to_csv("dataCleaned_with_sentiment.csv", index=False)

print("saved as dataCleaned_with_sentiment.csv")

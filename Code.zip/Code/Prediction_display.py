import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.ticker import ScalarFormatter
import matplotlib.ticker as ticker

data = pd.read_csv('dataset_with_predictions_full_final.csv')

def get_date(created_time):
    created_time = str(created_time).strip().split()[0]    #REMOVE TIME
    return pd.to_datetime(created_time, format="%Y%m%d")

data['created_time'] = data['created_time'].astype(str).apply(get_date)

data.set_index('created_time', inplace = True)

sentiment_average = data['sentiment_prediction'].resample('W').mean()
sentiment_numbers = sorted(data['sentiment_prediction'].unique())                   # Gets full sentiment score

sentiment_amount = data['sentiment_prediction'].value_counts()

#sentiment_overtime = data.groupby(['created_time', 'sentiment_prediction']).size().unstack()            # FOr most common sentiment weekly. idk why it works
#sentiment_overtime_most = sentiment_overtime.idxmax(axis = 1)
#data['created_time'] = data['created_time'].apply(get_date)
#sentiment_overtime = data.groupby([data['created_time'].dt.to_period('W'), 'sentiment_prediction']).size.unstack()
sentiment_weekly = data['sentiment_prediction'].resample('W').apply(lambda i:i.mode()[0] if not i.mode().empty else None)      #resamples weekly then gets the most common one or returns nothing

subreddit_amount = data['subreddit'].value_counts().head(10)

top_subreddits = subreddit_amount.index
avg_sub_sentiment = data.groupby('subreddit')['sentiment_prediction'].mean().loc[top_subreddits]

compare_sentiments_match = data['sentiment_score'] + 1        # Make equal to models predictions
sentiment_score_average = compare_sentiments_match.resample('W').mean()

data['self_text'] = data['self_text'].fillna('').astype(str) #Make sure all are strings

data_examples = data.groupby('sentiment_prediction').head(3)

def data_avg():
    plt.figure(figsize=(12, 6))
    plt.plot(sentiment_average.index, sentiment_average.values, marker='o', linestyle='-', color='b')
    plt.xlabel('Date')
    plt.ylabel('Average Sentiment')
    plt.yticks(sentiment_numbers)          # SHOWS FULL SENTIMENT SCORE
    plt.title('Average Weekly Sentiment Overtime')
    plt.grid(True)
    plt.show()

def most_common_sentiment():
    plt.figure(figsize=(12, 6))
    sns.barplot(x=sentiment_amount.index, y=sentiment_amount.values, palette='viridis')
    plt.xlabel('Sentiment Score')
    plt.ylabel('Frequency of Score')
   # plt.yticks(range(0, max(sentiment_amount.values) + 1, 100000))         # adust numbers on right to change y axis number gaps
    plt.title('Total Amount of Each Sentiment Score')
    plt.gca().yaxis.set_major_formatter(ScalarFormatter(useMathText=False))         # fix y axis to stop showing in scientific notation
    plt.ticklabel_format(style='plain', axis='y')
    plt.grid(True)
    plt.show()

def most_common_sentiment_overtime():
    plt.figure(figsize=(12, 6))
    plt.plot(sentiment_weekly.index, sentiment_weekly.values, marker='o', linestyle='-', color='b')
    plt.xlabel('Date')
    plt.ylabel('Sentiment Score')
    plt.title('Most Common Sentiment Score Overtime')
    plt.grid(True)
    plt.show()

def sentiment_upvotes():                                                                                            #FIX THIS ONE UTF8 ERROR GAPS IN DATASET
    sentiment_upvotes = data.groupby('sentiment_prediction')['ups'].sum()
    plt.figure(figsize=(12, 6))
    yaxis = sentiment_upvotes.plot(kind='bar', color='b')
    yaxis.yaxis.set_major_formatter(ticker.FuncFormatter(lambda x, _: f'{int(x):,}'))                             #Fixes y-axis to show correct numbers
    plt.xlabel('Sentiment Score')
    plt.xticks(rotation = 0)
    plt.ylabel('Upvotes')
    plt.title('Total Amount of Upvotes for Each Sentiment Score')
    plt.grid(True)
    plt.show()

def subbreddit_numbers():
    plt.figure(figsize=(12, 6))
    sns.barplot(x=subreddit_amount.values, y=subreddit_amount.index, palette='viridis')
    plt.xlabel('Amount Isreal Palestine is Mentioned')
    plt.ylabel('Subredit')
    plt.title('Top 10 Most Discussed Subreddits')
    plt.grid(True)
    plt.show()

def subbreddit_average_sentiment():
    plt.figure(figsize=(12, 6))
    sns.barplot(x=avg_sub_sentiment.values, y=avg_sub_sentiment.index, palette='viridis')
    plt.xlabel('Average Sentiment Score')
    plt.ylabel('Subreddit')
    plt.title('Average Sentiment in Subreddits')
    plt.grid(True)
    plt.show()


def compare_models():
    plt.figure(figsize=(12, 6))
    plt.plot(sentiment_score_average.index, sentiment_score_average.values, marker='o', linestyle='-', color='r', label='Training')
    plt.plot(sentiment_average.index, sentiment_average.values, marker='o', linestyle='-', color='b', label='LSTM')                #MAKE BOTH LINES THE AVERAGE
    plt.xlabel('Index')
    plt.ylabel('Sentiment')
    plt.title('Comparing Sentiment Training Values to Predicted Values')
    plt.legend(loc="upper left")
    plt.grid(True)
    plt.show()

def text_with_sentiment():
    plt.figure(figsize=(12, 6))
    barh = plt.barh(data_examples['self_text'], data_examples['sentiment_prediction'], color='b')

    for barh, self_text, sentiment_predictions in zip(barh, data_examples['self_text'], data_examples['sentiment_prediction']):
        plt.text(sentiment_predictions / 2, barh.get_y() + barh.get_height() / 2, self_text,
                 ha="center", va="center", fontsize=6, color="black")
    plt.xlabel('Text')
    plt.ylabel('Sentiment Prediction')
    plt.title('Example of Text with Sentiment Predictions')
    plt.xticks(rotation = 45, ha = 'right')        # Rotates text
    plt.xlim(-0.5, 2)
    plt.grid(True)
    plt.show()

def text_example():
    for rating in [0, 1, 2]:
        prediction = {0: "NEGATIVE", 1: "POSITIVE", 2: "NEGATIVE"}[rating]
        print(f"{prediction} Rating: {rating}")


        select_text = data[data['sentiment_prediction'] == rating]

        if select_text.empty:
            print("Nothing")
        else:
            text = select_text.sample(n=3) if len(select_text) >= 3 else select_text        # has to be N=
            for a, row in text.iterrows():
                print(f"Text: {row['self_text']}")

data_avg()
most_common_sentiment()
most_common_sentiment_overtime()
sentiment_upvotes()
subbreddit_numbers()
subbreddit_average_sentiment()
compare_models()
#text_with_sentiment()
text_example()
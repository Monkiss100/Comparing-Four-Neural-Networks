import pandas as pd
import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.preprocessing.text import Tokenizer


csv = "dataCleaned_with_sentiment_full_final.csv"
data = pd.read_csv(csv)
data["self_text"] = data["self_text"].astype(str).fillna("")

tokenizer = Tokenizer(num_words=10000)
tokenizer.fit_on_texts(data["self_text"])
max_len = 100
X_sequences = tokenizer.texts_to_sequences(data["self_text"])
X_padded = pad_sequences(X_sequences, maxlen=max_len)


model = tf.keras.models.load_model("lstm_opti4.keras")
predictions = model.predict(X_padded)
predicted_labels = np.argmax(predictions, axis=1)  # <- creates labels

data["sentiment_prediction"] = predicted_labels  # Create new coloum
data.to_csv("dataset_with_predictions_full_final.csv", index=False)

print("saved to dataset_with_predictions.csv")

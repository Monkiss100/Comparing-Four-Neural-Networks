import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
import tensorflow as tf
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.layers import TextVectorization
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense, Dropout, Embedding, GlobalAveragePooling1D
from sklearn.preprocessing import LabelEncoder , OneHotEncoder
from tensorflow.keras.layers import MultiHeadAttention, LayerNormalization, Add
import matplotlib.pyplot as plt
from sklearn.metrics import precision_score, recall_score, f1_score, confusion_matrix
import seaborn as sns
import time

start_time = time.time()

data = pd.read_csv('dataCleaned_with_sentiment.csv')

def preprocess_data(data):
    data['self_text'] = data['self_text'].fillna('').astype(str) #Make sure all are strings

    texts = data['self_text'].values
    labels = data['sentiment_score'].values

    # Tokenize and pad sequences
    tokenizer = Tokenizer(num_words=10000)
    tokenizer.fit_on_texts(texts)
    sequences = tokenizer.texts_to_sequences(texts)
    word_index = tokenizer.word_index
    padded_sequences = pad_sequences(sequences, maxlen=100)

    # Encode labels
    label_encoder = LabelEncoder()
    integer_labels = label_encoder.fit_transform(labels)
    integer_labels = integer_labels.reshape(-1, 1)

    one_hot_encoder = OneHotEncoder(sparse_output=False)
    one_hot_labels = one_hot_encoder.fit_transform(integer_labels)

    return padded_sequences, one_hot_labels, tokenizer, label_encoder

padded_sequences, one_hot_labels, tokenizer, label_encoder = preprocess_data(data)

# Split data
X_train, X_test, y_train, y_test = train_test_split(
    padded_sequences, one_hot_labels, test_size=0.2, random_state=10)

num_classes = one_hot_labels.shape[1]
max_words = 10000
max_len = 100
# Build transfomer model
class Transformer(tf.keras.layers.Layer):
    def __init__(self, embed_dim, num_heads, ff_dim, rate=0.1):
        super(Transformer, self).__init__()
        self.att = MultiHeadAttention(num_heads=num_heads, key_dim=embed_dim)
        self.ffn = tf.keras.Sequential([
            Dense(ff_dim, activation="relu"),
            Dense(embed_dim),
        ])
        self.layernorm1 = LayerNormalization(epsilon=1e-6)
        self.layernorm2 = LayerNormalization(epsilon=1e-6)
        self.dropout1 = Dropout(rate)
        self.dropout2 = Dropout(rate)

    def call(self, inputs, training):
        attn_output = self.att(inputs, inputs)
        attn_output = self.dropout1(attn_output, training=training)
        out1 = self.layernorm1(inputs + attn_output)
        ffn_output = self.ffn(out1)
        ffn_output = self.dropout2(ffn_output, training=training)
        return self.layernorm2(out1 + ffn_output)

# Transformer model definition
def build_transformer_model(max_len, max_features):              #fix this max feats
    inputs = Input(shape=(max_len,), dtype=tf.int32)
    x = Embedding(input_dim=max_words, output_dim=128)(inputs)
    transformer_model = Transformer(embed_dim=128, num_heads=4, ff_dim=128, rate=0.1)
    x = transformer_model(x, training=True)  # Pass training argument here
    x = GlobalAveragePooling1D()(x)
    x = Dense(64, activation='relu')(x)
    x = Dropout(0.5)(x)
    output = Dense(num_classes, activation='softmax')(x)

    model = Model(inputs, output)
    return model

model = build_transformer_model(max_len, num_classes)
model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
model.summary()

# Train the model
epochs = 10
batch_size = 32

history = model.fit(X_train, y_train, epochs=epochs, batch_size=batch_size, validation_split=0.2)

# Evaluate the model
eval_results = model.evaluate(X_test, y_test, verbose=0)
print(f"Test Loss: {eval_results[0]:.4f}, Test Accuracy: {eval_results[1]:.4f}")                      #Test Loss: 0.4886, Test Accuracy: 0.8329

#Runtime
end_time = time.time()
runtime = end_time - start_time
print(f"Runtime: {runtime:.3f} seconds")

# Predict on test data
y_pred_probs = model.predict(X_test)
y_pred_classes = np.argmax(y_pred_probs, axis=1)
y_true_classes = np.argmax(y_test, axis=1)

precision = precision_score(y_true_classes, y_pred_classes, average="weighted")                                                # Precision: 0.8376, Recall: 0.8389, F1-score: 0.8382
recall = recall_score(y_true_classes, y_pred_classes, average="weighted")
f1 = f1_score(y_true_classes, y_pred_classes, average="weighted")
print(f"Precision: {precision:.4f}, Recall: {recall:.4f}, F1-score: {f1:.4f}")

# Confusion matrix
conf_matrix = confusion_matrix(y_true_classes, y_pred_classes)                                              #Top left true negative, Top right false positive, Bottom left false negative, Bottom right true positive

# Visualize Confusion Matrix
plt.figure(figsize=(8, 6))
sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='Blues', xticklabels=np.unique(y_true_classes),
            yticklabels=np.unique(y_true_classes))
plt.xlabel('Predicted Labels')
plt.ylabel('True Labels')
plt.title('Transformer Confusion Matrix')
plt.show()


import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, LSTM, GlobalMaxPooling1D, Dense, Dropout
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder , OneHotEncoder
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
import matplotlib.pyplot as plt
from sklearn.metrics import precision_score, recall_score, f1_score, confusion_matrix
import seaborn as sns
import time

start_time = time.time()

data = pd.read_csv('dataCleaned_with_sentiment.csv')

def preprocess_data(data):
    data['self_text'] = data['self_text'].fillna('').astype(str) #Make sure all are strings

    texts = data['self_text'].values
    labels = data['sentiment_score'].values

    # Tokenize and pad sequences
    tokenizer = Tokenizer(num_words=10000)
    tokenizer.fit_on_texts(texts)
    sequences = tokenizer.texts_to_sequences(texts)
    word_index = tokenizer.word_index

    padded_sequences = pad_sequences(sequences, maxlen=100)

    # Encode labels
    label_encoder = LabelEncoder()
    integer_labels = label_encoder.fit_transform(labels)

    one_hot_encoder = OneHotEncoder(sparse_output=False)   #fix
    one_hot_labels = one_hot_encoder.fit_transform(integer_labels.reshape(-1, 1))

    return padded_sequences, one_hot_labels, tokenizer, label_encoder

padded_sequences, one_hot_labels, tokenizer, label_encoder = preprocess_data(data)

# Split data
X_train, X_test, y_train, y_test = train_test_split(
    padded_sequences, one_hot_labels, test_size=0.2, random_state=10)

# Build CNN model
model = Sequential([
    Embedding(input_dim=10000, output_dim=128, input_length=100),
    LSTM(128, return_sequences=True, dropout=0.2, recurrent_dropout=0.2),
    LSTM(64, dropout=0.2, recurrent_dropout=0.2),
    Dense(64, activation='relu'),
    Dropout(0.5),
    Dense(one_hot_labels.shape[1], activation='softmax')
])

model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

# Train the model
history = model.fit(
    X_train, y_train,
    epochs=10,
    batch_size=32,
    validation_split=0.2
)

# Evaluate the model
eval_results = model.evaluate(X_test, y_test, verbose=0)
print(f"Test Loss: {eval_results[0]:.4f}, Test Accuracy: {eval_results[1]:.4f}")         #Test Loss: 0.5381, Test Accuracy: 0.8541

#Runtime
end_time = time.time()
runtime = end_time - start_time
print(f"Runtime: {runtime:.3f} seconds")

# Predict on test data
y_pred_probs = model.predict(X_test)
y_pred_classes = np.argmax(y_pred_probs, axis=1)
y_true_classes = np.argmax(y_test, axis=1)

precision = precision_score(y_true_classes, y_pred_classes, average="weighted")                                                # Precision: 0.8376, Recall: 0.8389, F1-score: 0.8382
recall = recall_score(y_true_classes, y_pred_classes, average="weighted")
f1 = f1_score(y_true_classes, y_pred_classes, average="weighted")
print(f"Precision: {precision:.4f}, Recall: {recall:.4f}, F1-score: {f1:.4f}")

# Confusion matrix
conf_matrix = confusion_matrix(y_true_classes, y_pred_classes)                                              #Top left true negative, Top right false positive, Bottom left false negative, Bottom right true positive

# Visualize Confusion Matrix
plt.figure(figsize=(8, 6))
sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='Blues', xticklabels=np.unique(y_true_classes),
            yticklabels=np.unique(y_true_classes))
plt.xlabel('Predicted Labels')
plt.ylabel('True Labels')
plt.title('LSTM Confusion Matrix')
plt.show()

